# meraki_captive_portal_simulator
Local python simulation for Meraki Captive Portal Integration
